import React, { useState } from "react";
import OnboardingImage from "../images/onboarding-image.jpg";

function Onboarding01({ onNext, defaultData = {} }) {
  const [loanType, setLoanType] = useState(defaultData.loanType || "");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (loanType) {
      onNext({ loanType });
    }
  };

  return (
 

            <div className="px-4 py-8">
              <div className="max-w-md mx-auto">
                <h1 className="text-3xl text-gray-800 dark:text-gray-100 font-bold mb-6">I need </h1>

                <form onSubmit={handleSubmit}>
                  <div className="space-y-3 mb-8">
                    {[
                      { label: "Individual Loan", value: "individual", icon: "👤" },
                      { label: "Payroll Backed Loan", value: "payroll", icon: "🏢" },
                    ].map((option) => (
                      <label key={option.value} className="relative block cursor-pointer">
                        <input
                          type="radio"
                          name="loanType"
                          value={option.value}
                          onChange={() => setLoanType(option.value)}
                          checked={loanType === option.value}
                          className="peer sr-only"
                        />
                        <div className="flex items-center bg-white dark:bg-gray-800 text-sm font-medium text-gray-800 dark:text-gray-100 p-4 rounded-lg border border-gray-200 dark:border-gray-700/60 hover:border-gray-300 dark:hover:border-gray-600 shadow-xs transition peer-checked:border-violet-500">
                          <span className="text-xl mr-4">{option.icon}</span>
                          <span>{option.label}</span>
                        </div>
                      </label>
                    ))}
                  </div>

                  <div className="flex items-center justify-between">
                    <button
                      type="submit"
                      className="btn bg-gray-900 text-gray-100 hover:bg-gray-800 dark:bg-gray-100 dark:text-gray-800 dark:hover:bg-white ml-auto disabled:opacity-50"
                      disabled={!loanType}
                    >
                      Next
                    </button>
                  </div>
                </form>
              </div>
            </div>

  );
}

export default Onboarding01;
