import React, { useState } from "react";
import {
  resetBorrowerData,
  resetBorrowerFile,
  registerBorrower,
  updateAddBorrowerField,
  uploadBorrowerPhotoFile,
  getDraftBorrowerByID,
} from "../../redux/Slices/personalBorrowersSlice";

function Onboarding03({ onNext, onBack, defaultData }) {
  const [email, setEmail] = useState(defaultData.email || "");
  const [basicPay, setBasicPay] = useState(defaultData.basicPay || "");

  const handleSubmit = (e) => {
    e.preventDefault();
    onNext({ email, basicPay });
  };

  return (
      <div className="p-4 max-w-md mx-auto">
        <h1 className="text-2xl font-bold mb-4">Contact & Salary</h1>
        <form onSubmit={handleSubmit}>
          <input
            className="form-input w-full mb-4"
            type="email"
            placeholder="Email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            required
          />
          <input
            className="form-input w-full mb-4"
            type="number"
            placeholder="Basic Pay"
            value={basicPay}
            onChange={e => setBasicPay(e.target.value)}
            required
          />
          <div className="flex justify-between">
            <button
              type="button"
              onClick={onBack}
              className="btn bg-gray-300 text-black px-4 py-2 rounded"
            >
              Previous
            </button>
            <button
              type="submit"
              className="btn bg-violet-500 text-white px-4 py-2 rounded"
            >
              Next
            </button>
          </div>
        </form>
      </div>

  );
}

export default Onboarding03;
